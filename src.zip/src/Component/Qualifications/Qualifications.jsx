import React from 'react'

const Qualifications = () => {
    return (
        <div className='qualifications-main section-padding'>
            <div className="row">
                <div className="col-md-12 col-sm-12 col-lg-12">
                    <div className="qualifications-heading heading-with-sub">
                        {/* <h6 className="p-0 m-0">Get in Touch with Us</h6> */}
                        <h3 className="p-0 m-0">Qualification</h3>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Qualifications
